import{initializeApp}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import{getDatabase,ref,set,get,onValue}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";
import{getAuth,signInAnonymously}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

const firebaseConfig={
apiKey:"AIzaSyD5kH_VWXI2r_znQbhlHenqDEZBJmnJcFM",
authDomain:"camra-share.firebaseapp.com",
databaseURL:"https://camra-share-default-rtdb.asia-southeast1.firebasedatabase.app",
projectId:"camra-share",
storageBucket:"camra-share.firebasestorage.app",
messagingSenderId:"618409884143",
appId:"1:618409884143:web:d787884065b651f54f9e1a",
measurementId:"G-ZLF7B4GFR4"};
const app=initializeApp(firebaseConfig),db=getDatabase(app),auth=getAuth(app);
await signInAnonymously(auth);

const home=document.getElementById("home"),guest=document.getElementById("guest"),host=document.getElementById("host");
const createBtn=document.getElementById("createBtn"),pressBtn=document.getElementById("pressBtn");
const homeStatus=document.getElementById("homeStatus"),guestTitle=document.getElementById("guestTitle"),guestText=document.getElementById("guestText");
const countdown=document.getElementById("countdown"),hostStatus=document.getElementById("hostStatus"),inviteLink=document.getElementById("inviteLink"),copyBtn=document.getElementById("copyBtn");
const pressCount=document.getElementById("pressCount"),stageCount=document.getElementById("stageCount"),hostEvent=document.getElementById("hostEvent"),hostLog=document.getElementById("hostLog");
const connectionDot=document.getElementById("connectionDot"),connectionText=document.getElementById("connectionText");

function show(s){home.classList.add("hidden");guest.classList.add("hidden");host.classList.add("hidden");s.classList.remove("hidden")}
function id(){return Math.random().toString(36).slice(2,10)+Date.now().toString(36).slice(-4)}
function addLog(t){const x=document.createElement("div");x.textContent="• "+t;hostLog.prepend(x)}

const room=new URLSearchParams(location.search).get("room");

if(!room){
createBtn.onclick=async()=>{
createBtn.disabled=true;homeStatus.textContent="Room ban raha hai...";
const rid=id();
await set(ref(db,`dontPressRooms/${rid}`),{createdAt:Date.now(),presses:0,stage:0,event:"Room created"});
const u=new URL(location.href);u.search="";u.searchParams.set("room",rid);
inviteLink.value=u.toString();show(host);
hostStatus.textContent="Guest ko link bhejo. Uske actions yahan live aayenge.";
copyBtn.onclick=async()=>{try{await navigator.clipboard.writeText(inviteLink.value);copyBtn.textContent="✅ Copied";setTimeout(()=>copyBtn.textContent="Copy Link",1800)}catch{inviteLink.select();document.execCommand("copy")}};
onValue(ref(db,`dontPressRooms/${rid}`),s=>{
const d=s.val();if(!d)return;
pressCount.textContent=d.presses||0;stageCount.textContent=d.stage||0;
if(d.presses>0){connectionText.textContent="Guest Active";connectionDot.classList.add("online");hostStatus.textContent="🟢 Guest connected hai aur game khel raha hai."}
if(d.event&&d.event!=="Room created")hostEvent.textContent=d.event;
});
onValue(ref(db,`dontPressRooms/${rid}/events`),s=>{
hostLog.innerHTML="";const d=s.val();if(!d)return;Object.values(d).sort((a,b)=>a.time-b.time).reverse().forEach(e=>addLog(e.text));
});
};
}else{
show(guest);
const snap=await get(ref(db,`dontPressRooms/${room}`));
if(!snap.exists()){guestTitle.textContent="Room Not Found";guestText.textContent="Ye secret room valid nahi hai.";pressBtn.classList.add("hidden")}
else{
let presses=0,stage=0,locked=false;
pressBtn.onclick=async()=>{
if(locked)return;presses++;stage=Math.min(5,Math.floor((presses-1)/2)+1);
let title,text,event;
if(presses===1){title="😳 TUMNE PRESS KAR DIYA!";text="Maine bola tha DON'T PRESS!";event="😳 Guest ne first time button press kiya!"}
else if(presses===2){title="😂 AGAIN?!";text="Tum seriously rukne wale nahi ho.";event="😂 Guest ne dobara press kiya!"}
else if(presses===3){title="🚨 WARNING";text="Ab game tumhe test karega...";event="🚨 Stage 2 unlocked!"}
else if(presses===4){title="👀 TOO LATE";text="Ab button tumhe dhundhega.";event="👀 Guest reached Stage 3."}
else if(presses===5){title="⏳ 5 SECONDS...";text="Ab countdown start!";event="⏳ Countdown started!";locked=true;pressBtn.classList.add("hidden");countdown.classList.remove("hidden");let n=5;countdown.textContent=n;const t=setInterval(()=>{n--;countdown.textContent=n;if(n<=0){clearInterval(t);countdown.textContent="💥";locked=false;pressBtn.classList.remove("hidden");guestTitle.textContent="🔓 SECRET MODE";guestText.textContent="Tumne rule tod diya. Obviously. 😂";pressBtn.textContent="🔴 PRESS AGAIN"}},800)}
else{title=presses>=8?"😈 FINAL FORM":"🏆 YOU CAN'T RESIST!";text=presses>=8?"Okay... you win. 😂":`Tumne ${presses} baar press kar diya!`;event=presses>=8?"😈 Guest reached FINAL FORM!":`🏆 Guest has pressed ${presses} times!`}
guestTitle.textContent=title;guestText.textContent=text;guest.classList.remove("shake");void guest.offsetWidth;guest.classList.add("shake");
await set(ref(db,`dontPressRooms/${room}`),{createdAt:snap.val().createdAt||Date.now(),presses,stage,event,updatedAt:Date.now()});
await set(ref(db,`dontPressRooms/${room}/events/${Date.now()}`),{text,event,time:Date.now()});
};
}}
}